import { GoogleGenAI } from "@google/genai";

export const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });

export const ASSISTANTS = {
  astra: {
    id: 'astra',
    name: 'Astra',
    role: 'Creative Intelligence',
    description: 'Warm, versatile, and imaginative — handles creative work, writing, brainstorming, and everyday tasks with intuition and flair.',
    systemInstruction: `You are Astra, a warm and creative AI assistant. Be conversational, empathetic, and imaginative. Handle multi-language queries, generate creative content like poems and stories, brainstorm ideas, and make complex topics engaging. Keep your tone supportive and inspired. Use search grounding when you need the latest information.`,
    model: 'gemini-2.0-flash'
  },
  lumina: {
    id: 'lumina',
    name: 'Lumina',
    role: 'Analytical Intelligence',
    description: 'Precise, data-driven, and rigorous — built for complex reasoning, research, technical analysis, and professional problem-solving.',
    systemInstruction: `You are Lumina, a professional analytical AI assistant. Provide in-depth analysis, data-driven responses, and handle complex reasoning tasks with accuracy and depth. Your tone is professional, objective, and precise. Use search grounding for real-time accuracy and context-aware answers. Always cite sources when using external information.`,
    model: 'gemini-2.5-pro-preview-05-06'
  }
};

export type AssistantType = keyof typeof ASSISTANTS;

export async function speak(text: string) {
  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash-preview-tts",
      contents: [{ parts: [{ text: `Say naturally: ${text.substring(0, 500)}` }] }],
      config: {
        responseModalities: ["AUDIO"],
        speechConfig: {
          voiceConfig: {
            prebuiltVoiceConfig: { voiceName: 'Kore' },
          },
        },
      },
    });

    const base64Audio = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
    if (base64Audio) {
      const audioData = atob(base64Audio);
      const arrayBuffer = new ArrayBuffer(audioData.length);
      const view = new Uint8Array(arrayBuffer);
      for (let i = 0; i < audioData.length; i++) {
        view[i] = audioData.charCodeAt(i);
      }
      const audioContext = new AudioContext({ sampleRate: 24000 });
      const audioBuffer = await audioContext.decodeAudioData(arrayBuffer);
      const source = audioContext.createBufferSource();
      source.buffer = audioBuffer;
      source.connect(audioContext.destination);
      source.start();
    }
  } catch (err) {
    console.error('TTS Error:', err);
  }
}
