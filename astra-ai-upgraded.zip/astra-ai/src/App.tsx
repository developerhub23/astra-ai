import React, { useState, useEffect } from 'react';
import {
  collection, query, orderBy, onSnapshot, addDoc,
  serverTimestamp, doc, deleteDoc, where, getDocFromServer
} from 'firebase/firestore';
import {
  signInWithPopup, GoogleAuthProvider, onAuthStateChanged, User as FirebaseUser
} from 'firebase/auth';
import { db, auth } from './firebase';
import { ChatSession } from './types';
import { AssistantType } from './gemini';
import Sidebar from './components/Sidebar';
import ChatInterface from './components/ChatInterface';
import AnalyticsDashboard from './components/AnalyticsDashboard';
import { motion, AnimatePresence } from 'motion/react';
import { Zap, ShieldCheck, Lock, ArrowRight, Activity } from 'lucide-react';

export default function App() {
  const [user, setUser] = useState<FirebaseUser | null>(null);
  const [authLoading, setAuthLoading] = useState(true);
  const [sessions, setSessions] = useState<ChatSession[]>([]);
  const [activeSessionId, setActiveSessionId] = useState<string | null>(null);
  const [currentView, setCurrentView] = useState<'chat' | 'analytics' | 'audit'>('chat');

  useEffect(() => {
    async function testConnection() {
      try {
        await getDocFromServer(doc(db, 'test', 'connection'));
      } catch (error) {
        if (error instanceof Error && error.message.includes('the client is offline')) {
          console.error("Please check your Firebase configuration.");
        }
      }
    }
    testConnection();
    const unsub = onAuthStateChanged(auth, (u) => { setUser(u); setAuthLoading(false); });
    return () => unsub();
  }, []);

  useEffect(() => {
    if (!user) return;
    const q = query(
      collection(db, 'sessions'),
      where('userId', '==', user.uid),
      orderBy('updatedAt', 'desc')
    );
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const sess = snapshot.docs.map(d => ({ id: d.id, ...d.data() } as ChatSession));
      setSessions(sess);
    });
    return () => unsubscribe();
  }, [user]);

  const handleLogin = async () => {
    try {
      const provider = new GoogleAuthProvider();
      await signInWithPopup(auth, provider);
    } catch (error) {
      console.error('Login error:', error);
    }
  };

  const handleNewSession = async (type: AssistantType) => {
    if (!user) return;
    try {
      const docRef = await addDoc(collection(db, 'sessions'), {
        title: 'New Session',
        assistantType: type,
        updatedAt: serverTimestamp(),
        createdAt: serverTimestamp(),
        lastMessage: '',
        userId: user.uid
      });
      setActiveSessionId(docRef.id);
      setCurrentView('chat');
    } catch (error) {
      console.error('Error creating session:', error);
    }
  };

  const handleDeleteSession = async (id: string) => {
    try {
      await deleteDoc(doc(db, 'sessions', id));
      if (activeSessionId === id) setActiveSessionId(null);
    } catch (error) {
      console.error('Error deleting session:', error);
    }
  };

  const activeSession = sessions.find(s => s.id === activeSessionId) || null;

  if (authLoading) {
    return (
      <div className="h-screen w-screen flex items-center justify-center" style={{ background: '#0C0C10' }}>
        <div className="flex flex-col items-center gap-6">
          <div className="relative">
            <div className="w-16 h-16 rounded-2xl flex items-center justify-center" style={{ background: 'rgba(200,241,53,0.1)', border: '1px solid rgba(200,241,53,0.2)' }}>
              <Zap size={28} color="#C8F135" />
            </div>
            <div className="absolute inset-0 rounded-2xl" style={{ animation: 'pulse-live 2s ease-in-out infinite', boxShadow: '0 0 40px rgba(200,241,53,0.3)' }} />
          </div>
          <span className="mono-label" style={{ color: 'rgba(200,241,53,0.6)' }}>Initializing Neural Core...</span>
        </div>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="h-screen w-screen flex overflow-hidden" style={{ background: '#0C0C10', fontFamily: 'Syne, sans-serif' }}>
        {/* Ambient background effects */}
        <div className="absolute inset-0 pointer-events-none overflow-hidden">
          <div style={{ position: 'absolute', top: '-20%', left: '-10%', width: '700px', height: '700px', background: 'radial-gradient(circle, rgba(200,241,53,0.06) 0%, transparent 70%)', borderRadius: '50%' }} />
          <div style={{ position: 'absolute', bottom: '-20%', right: '-10%', width: '600px', height: '600px', background: 'radial-gradient(circle, rgba(137,212,245,0.05) 0%, transparent 70%)', borderRadius: '50%' }} />
          {/* Grid overlay */}
          <div style={{ position: 'absolute', inset: 0, backgroundImage: 'linear-gradient(rgba(255,255,255,0.02) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,0.02) 1px, transparent 1px)', backgroundSize: '60px 60px' }} />
        </div>

        {/* Left: Branding column */}
        <div className="flex-1 flex flex-col justify-between p-16 relative z-10">
          {/* Logo */}
          <div className="flex items-center gap-3">
            <div style={{ width: 36, height: 36, borderRadius: 10, background: '#C8F135', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
              <Zap size={20} color="#0C0C10" strokeWidth={2.5} />
            </div>
            <span style={{ fontFamily: 'Syne, sans-serif', fontWeight: 800, fontSize: 18, color: '#F0EFE8', letterSpacing: '-0.02em' }}>Astra AI</span>
          </div>

          {/* Hero */}
          <div className="space-y-10 max-w-xl">
            <div className="pill" style={{ marginBottom: 24 }}>
              <span className="dot-live" />
              Dual-Engine Intelligence — Live
            </div>
            <h1 style={{ fontFamily: 'Syne, sans-serif', fontWeight: 800, fontSize: 'clamp(52px, 6vw, 88px)', lineHeight: 0.88, letterSpacing: '-0.04em', color: '#F0EFE8' }}>
              Think<br/>
              <span style={{ fontFamily: 'Fraunces, serif', fontStyle: 'italic', fontWeight: 700 }} className="gradient-text">Deeper.</span><br />
              Move Faster.
            </h1>
            <p style={{ fontSize: 17, lineHeight: 1.7, color: 'rgba(240,239,232,0.55)', fontWeight: 400, maxWidth: 440 }}>
              Two specialized intelligence engines — creative and analytical — working in concert. Built for professionals who demand more than generic AI.
            </p>

            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 24, paddingTop: 16, borderTop: '1px solid rgba(255,255,255,0.06)' }}>
              {[
                { label: 'Creative Engine', desc: 'Astra — imaginative & warm', color: '#C8F135' },
                { label: 'Analytical Engine', desc: 'Lumina — precise & rigorous', color: '#89D4F5' }
              ].map(item => (
                <div key={item.label}>
                  <div style={{ width: 8, height: 8, borderRadius: '50%', background: item.color, boxShadow: `0 0 12px ${item.color}80`, marginBottom: 8 }} />
                  <div style={{ fontWeight: 700, fontSize: 13, color: '#F0EFE8', marginBottom: 2 }}>{item.label}</div>
                  <div className="mono-label">{item.desc}</div>
                </div>
              ))}
            </div>
          </div>

          {/* Footer stats */}
          <div className="flex gap-12">
            {[['99.98%', 'Uptime SLA'], ['<150ms', 'Avg Latency'], ['AES-256', 'Encryption']].map(([val, label]) => (
              <div key={label}>
                <div style={{ fontWeight: 800, fontSize: 20, color: '#F0EFE8', letterSpacing: '-0.02em' }}>{val}</div>
                <div className="mono-label">{label}</div>
              </div>
            ))}
          </div>
        </div>

        {/* Right: Auth panel */}
        <div className="w-full lg:w-[440px] flex flex-col justify-center p-16 relative z-10" style={{ background: 'rgba(20,20,26,0.6)', backdropFilter: 'blur(40px)', borderLeft: '1px solid rgba(255,255,255,0.05)' }}>
          <div className="max-w-xs w-full mx-auto space-y-8">
            <div>
              <div style={{ display: 'inline-flex', alignItems: 'center', gap: 6, padding: '4px 12px', borderRadius: 100, background: 'rgba(200,241,53,0.08)', border: '1px solid rgba(200,241,53,0.2)', marginBottom: 20 }}>
                <ShieldCheck size={11} color="#C8F135" />
                <span style={{ fontFamily: 'JetBrains Mono, monospace', fontSize: 9, textTransform: 'uppercase', letterSpacing: '0.15em', color: '#C8F135' }}>Secure Access</span>
              </div>
              <h2 style={{ fontFamily: 'Syne, sans-serif', fontWeight: 800, fontSize: 36, letterSpacing: '-0.03em', color: '#F0EFE8', lineHeight: 1.05, marginBottom: 10 }}>
                Welcome<br/>Back.
              </h2>
              <p style={{ fontSize: 13, color: 'rgba(240,239,232,0.45)', lineHeight: 1.7 }}>
                Sign in with your Google account to access your personalized intelligence workspace.
              </p>
            </div>

            <button onClick={handleLogin} className="luxury-button" style={{ width: '100%' }}>
              <div style={{ width: 20, height: 20, background: 'white', borderRadius: 4, display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 3, flexShrink: 0 }}>
                <svg viewBox="0 0 24 24" style={{ width: '100%', height: '100%' }}>
                  <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" fill="#4285F4"/>
                  <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-1.01.68-2.31 1.09-3.71 1.09-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853"/>
                  <path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l3.66-2.84z" fill="#FBBC05"/>
                  <path d="M12 5.38c1.62 0 3.06.56 4.21 1.63l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335"/>
                </svg>
              </div>
              <span>Continue with Google</span>
              <ArrowRight size={16} />
            </button>

            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
              {[
                { icon: '🔒', label: 'End-to-end encrypted' },
                { icon: '🛡️', label: 'GDPR compliant' },
                { icon: '🔑', label: 'Zero data sold' },
                { icon: '⚡', label: 'Instant access' },
              ].map(item => (
                <div key={item.label} style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '10px 12px', borderRadius: 10, background: 'rgba(255,255,255,0.03)', border: '1px solid rgba(255,255,255,0.05)' }}>
                  <span style={{ fontSize: 14 }}>{item.icon}</span>
                  <span style={{ fontFamily: 'JetBrains Mono, monospace', fontSize: 9, textTransform: 'uppercase', letterSpacing: '0.1em', color: 'rgba(240,239,232,0.4)' }}>{item.label}</span>
                </div>
              ))}
            </div>

            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6, paddingTop: 8 }}>
              <Lock size={10} color="rgba(240,239,232,0.2)" />
              <span className="mono-label">AES-256 · TLS 1.3 · SOC 2</span>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="h-screen w-screen flex overflow-hidden" style={{ background: '#0C0C10' }}>
      <Sidebar
        sessions={sessions}
        activeSessionId={activeSessionId}
        onSelectSession={setActiveSessionId}
        onNewChat={() => setActiveSessionId(null)}
        onViewChange={setCurrentView}
        currentView={currentView}
        onDeleteSession={handleDeleteSession}
      />
      <main className="flex-1 flex flex-col h-full overflow-hidden">
        <AnimatePresence mode="wait">
          {currentView === 'chat' ? (
            <motion.div key="chat" initial={{ opacity: 0, x: 16 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -16 }} transition={{ duration: 0.2 }} className="flex-1 h-full">
              <ChatInterface session={activeSession} onNewSession={handleNewSession} />
            </motion.div>
          ) : currentView === 'analytics' ? (
            <motion.div key="analytics" initial={{ opacity: 0, scale: 0.99 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0, scale: 1.01 }} transition={{ duration: 0.2 }} className="flex-1 h-full">
              <AnalyticsDashboard />
            </motion.div>
          ) : (
            <motion.div key="audit" initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -16 }} transition={{ duration: 0.2 }} className="flex-1 h-full overflow-y-auto p-10" style={{ background: '#0C0C10' }}>
              <div className="max-w-3xl mx-auto space-y-10">
                <header className="space-y-4">
                  <div className="pill w-fit">
                    <ShieldCheck size={10} />
                    Security Active
                  </div>
                  <h1 style={{ fontFamily: 'Syne, sans-serif', fontWeight: 800, fontSize: 52, letterSpacing: '-0.04em', lineHeight: 0.9, color: '#F0EFE8' }}>
                    Intelligence<br/><span className="gradient-text">Audit Log</span>
                  </h1>
                  <p style={{ color: 'rgba(240,239,232,0.5)', fontSize: 15, lineHeight: 1.7 }}>Complete transparency for AI operations and data handling.</p>
                </header>

                <div className="glass-card overflow-hidden">
                  <div style={{ padding: '12px 20px', borderBottom: '1px solid rgba(255,255,255,0.06)', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                    <span className="mono-label">Real-time Event Stream</span>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                      <span className="dot-live" />
                      <span className="mono-label">Live</span>
                    </div>
                  </div>
                  <div style={{ padding: 20, display: 'flex', flexDirection: 'column', gap: 12 }}>
                    {[
                      { event: 'User Authentication', detail: user.email || '', status: 'VERIFIED', ok: true },
                      { event: 'Session Initialized', detail: 'Neural core ready', status: 'ACTIVE', ok: true },
                      { event: 'Search Grounding', detail: 'Google API connected', status: 'GROUNDED', ok: true },
                      { event: 'Privacy Compliance', detail: 'GDPR · CCPA', status: 'PASSED', ok: true },
                      { event: 'System Health', detail: 'All nodes nominal', status: 'NOMINAL', ok: true },
                    ].map((log, i) => (
                      <div key={i} style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', paddingBottom: 12, borderBottom: i < 4 ? '1px solid rgba(255,255,255,0.04)' : 'none' }}>
                        <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
                          <span style={{ fontFamily: 'JetBrains Mono, monospace', fontSize: 10, color: 'rgba(240,239,232,0.2)' }}>[{new Date().toLocaleTimeString()}]</span>
                          <div>
                            <div style={{ fontSize: 13, color: '#F0EFE8', fontWeight: 500 }}>{log.event}</div>
                            <div className="mono-label" style={{ marginTop: 2 }}>{log.detail}</div>
                          </div>
                        </div>
                        <span style={{ padding: '3px 10px', borderRadius: 100, fontFamily: 'JetBrains Mono, monospace', fontSize: 9, textTransform: 'uppercase', letterSpacing: '0.1em', background: 'rgba(200,241,53,0.1)', color: '#C8F135', border: '1px solid rgba(200,241,53,0.2)' }}>
                          {log.status}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>

                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16 }}>
                  {[
                    { title: 'Data Retention', value: '90 days', desc: 'Automatic purge after 90 days' },
                    { title: 'Encryption', value: 'AES-256', desc: 'At rest and in transit' },
                    { title: 'Access Control', value: 'OAuth 2.0', desc: 'Google identity provider' },
                    { title: 'Compliance', value: 'SOC 2', desc: 'Type II certified infrastructure' },
                  ].map(item => (
                    <div key={item.title} className="glass-card" style={{ padding: 20 }}>
                      <div className="mono-label" style={{ marginBottom: 6 }}>{item.title}</div>
                      <div style={{ fontFamily: 'Syne, sans-serif', fontWeight: 800, fontSize: 24, color: '#C8F135', letterSpacing: '-0.02em', marginBottom: 4 }}>{item.value}</div>
                      <div style={{ fontSize: 12, color: 'rgba(240,239,232,0.4)' }}>{item.desc}</div>
                    </div>
                  ))}
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </main>
    </div>
  );
}
